from django.urls import path
from Shop.views import main_page, product_list, create_object, product_detail

app_name = 'Shop'

urlpatterns = [
    path('', main_page, name='main_page'),
    path('shop/', product_list, name='product_list'),
    path('create/', create_object, name='create_object'),
    path('detail/<int:id>/', product_detail, name='product_detail')
]

