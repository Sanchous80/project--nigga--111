from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect, get_object_or_404
from Shop.models import Product
from Shop.forms import ProductForm


def main_page(request):
    return HttpResponse('<h1 style="color: red">Main Page!!!</h1>')


def product_list(request):
    queryset = Product.objects.all()
    context = {
        'title': 'Main page',
        'objects_list': queryset
    }
    return render(request, 'main_page.html', context)


def create_object(request):
    form = ProductForm(request.POST or None)
    if form.is_valid():
        instance = form.save(commit=False)
        instance.save()
        return redirect('Shop:product_list')
    context = {
        'title': 'Create product',
        'form': form
    }
    return render(request, 'create_product.html', context)


def product_detail(request, id=None):
    instance = get_object_or_404(Product, id=id)
    context = {
        'title': 'Detail info',
        'product': instance
    }
    return render(request, 'detail_page.html', context)


