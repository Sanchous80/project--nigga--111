from django.contrib import admin
from Shop.models import Product


class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'type', 'price', 'show', 'update', 'timestamp')
    list_filter = ('price', 'type')
    list_editable = ('price', 'type', 'name', 'show')
    list_display_links = ('update', )


admin.site.register(Product, ProductAdmin)

